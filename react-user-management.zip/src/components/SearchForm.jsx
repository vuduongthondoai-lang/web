export default function SearchForm({ onChangeValue }) {
  return (
    <label className="search-box">
      <span aria-hidden="true">⌕</span>
      <input
        type="search"
        placeholder="Tìm theo tên hoặc username..."
        onChange={(event) => onChangeValue(event.target.value)}
      />
    </label>
  );
}