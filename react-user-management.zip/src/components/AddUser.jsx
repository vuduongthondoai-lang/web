import { useState } from "react";

const emptyUser = {
  name: "",
  username: "",
  email: "",
  phone: "",
  address: { street: "", suite: "", city: "" }
};

export default function AddUser({ onAdd }) {
  const [open, setOpen] = useState(false);
  const [user, setUser] = useState(emptyUser);

  function handleChange(event) {
    const { name, value } = event.target;
    if (["street", "suite", "city"].includes(name)) {
      setUser((prev) => ({
        ...prev,
        address: { ...prev.address, [name]: value }
      }));
    } else {
      setUser((prev) => ({ ...prev, [name]: value }));
    }
  }

  function handleSubmit(event) {
    event.preventDefault();
    if (!user.name.trim() || !user.username.trim()) {
      alert("Vui lòng nhập Họ tên và Username.");
      return;
    }
    onAdd({ ...user, address: { ...user.address } });
    setUser(emptyUser);
    setOpen(false);
  }

  return (
    <>
      <button className="button primary" onClick={() => setOpen(true)}>
        <span>＋</span> Thêm người dùng
      </button>
      {open && (
        <div className="modal-backdrop" role="presentation" onMouseDown={(e) => {
          if (e.target === e.currentTarget) setOpen(false);
        }}>
          <section className="modal" role="dialog" aria-modal="true" aria-labelledby="add-title">
            <div className="modal-heading">
              <div><p className="eyebrow">THÔNG TIN TÀI KHOẢN</p><h2 id="add-title">Thêm người dùng</h2></div>
              <button className="icon-button" onClick={() => setOpen(false)} aria-label="Đóng">×</button>
            </div>
            <form onSubmit={handleSubmit} className="form-grid">
              <label>Họ tên *<input name="name" value={user.name} onChange={handleChange} required /></label>
              <label>Username *<input name="username" value={user.username} onChange={handleChange} required /></label>
              <label>Email<input name="email" type="email" value={user.email} onChange={handleChange} /></label>
              <label>Số điện thoại<input name="phone" value={user.phone} onChange={handleChange} /></label>
              <label>Đường<input name="street" value={user.address.street} onChange={handleChange} /></label>
              <label>Căn hộ / Số nhà<input name="suite" value={user.address.suite} onChange={handleChange} /></label>
              <label className="full">Thành phố<input name="city" value={user.address.city} onChange={handleChange} /></label>
              <div className="form-actions full">
                <button type="button" className="button secondary" onClick={() => setOpen(false)}>Hủy</button>
                <button type="submit" className="button primary">Lưu người dùng</button>
              </div>
            </form>
          </section>
        </div>
      )}
    </>
  );
}