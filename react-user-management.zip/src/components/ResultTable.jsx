import { useEffect, useMemo, useState } from "react";

export default function ResultTable({ keyword, user, onAdded }) {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState(null);

  // Đọc dữ liệu API một lần khi component được tạo.
  useEffect(() => {
    let active = true;
    fetch("https://jsonplaceholder.typicode.com/users")
      .then((response) => {
        if (!response.ok) throw new Error("Không thể tải dữ liệu từ API.");
        return response.json();
      })
      .then((data) => {
        if (active) setUsers(data);
      })
      .catch((err) => {
        if (active) setError(err.message);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => { active = false; };
  }, []);

  // Nhận user mới từ App rồi thêm vào danh sách.
  useEffect(() => {
    if (user) {
      setUsers((prev) => [
        ...prev,
        { ...user, id: prev.length ? Math.max(...prev.map((u) => u.id)) + 1 : 1 }
      ]);
      onAdded();
    }
  }, [user, onAdded]);

  const filteredUsers = useMemo(() => {
    const normalized = keyword.trim().toLowerCase();
    if (!normalized) return users;
    return users.filter((u) =>
      (u.name || "").toLowerCase().includes(normalized) ||
      (u.username || "").toLowerCase().includes(normalized)
    );
  }, [users, keyword]);

  function startEdit(u) {
    setEditing({ ...u, address: { ...(u.address || {}) } });
  }

  function updateEditing(event) {
    const { name, value } = event.target;
    if (["street", "suite", "city"].includes(name)) {
      setEditing((prev) => ({
        ...prev,
        address: { ...prev.address, [name]: value }
      }));
    } else {
      setEditing((prev) => ({ ...prev, [name]: value }));
    }
  }

  function saveEdit(event) {
    event.preventDefault();
    setUsers((prev) => prev.map((u) => u.id === editing.id ? editing : u));
    setEditing(null);
  }

  function removeUser(id) {
    if (window.confirm("Bạn có chắc muốn xóa người dùng này?")) {
      setUsers((prev) => prev.filter((u) => u.id !== id));
    }
  }

  if (loading) return <p className="state-message">Đang tải danh sách người dùng...</p>;
  if (error) return <p className="state-message error">{error} Hãy kiểm tra kết nối Internet và tải lại trang.</p>;

  return (
    <>
      <div className="table-summary">
        <div><h2>Danh sách người dùng</h2><p>Thông tin được tải từ JSONPlaceholder</p></div>
        <span className="count">{filteredUsers.length} người dùng</span>
      </div>
      <div className="table-wrap">
        <table>
          <thead><tr>
            <th>ID</th><th>Họ tên</th><th>Username</th><th>Email</th><th>Địa chỉ</th><th>Điện thoại</th><th>Thao tác</th>
          </tr></thead>
          <tbody>
            {filteredUsers.map((u) => (
              <tr key={u.id}>
                <td className="id-cell">{u.id}</td>
                <td className="name-cell">{u.name}</td>
                <td>{u.username}</td>
                <td>{u.email}</td>
                <td>{[u.address?.street, u.address?.suite, u.address?.city].filter(Boolean).join(", ") || "—"}</td>
                <td>{u.phone || "—"}</td>
                <td><div className="actions">
                  <button className="button small secondary" onClick={() => startEdit(u)}>Sửa</button>
                  <button className="button small danger" onClick={() => removeUser(u.id)}>Xóa</button>
                </div></td>
              </tr>
            ))}
            {filteredUsers.length === 0 && <tr><td colSpan="7" className="empty">Không tìm thấy người dùng phù hợp.</td></tr>}
          </tbody>
        </table>
      </div>

      {editing && (
        <div className="modal-backdrop">
          <section className="modal" role="dialog" aria-modal="true" aria-labelledby="edit-title">
            <div className="modal-heading">
              <div><p className="eyebrow">CẬP NHẬT THÔNG TIN</p><h2 id="edit-title">Sửa người dùng #{editing.id}</h2></div>
              <button className="icon-button" onClick={() => setEditing(null)} aria-label="Đóng">×</button>
            </div>
            <form onSubmit={saveEdit} className="form-grid">
              <label>Họ tên<input name="name" value={editing.name || ""} onChange={updateEditing} required /></label>
              <label>Username<input name="username" value={editing.username || ""} onChange={updateEditing} required /></label>
              <label>Email<input name="email" type="email" value={editing.email || ""} onChange={updateEditing} /></label>
              <label>Số điện thoại<input name="phone" value={editing.phone || ""} onChange={updateEditing} /></label>
              <label>Đường<input name="street" value={editing.address?.street || ""} onChange={updateEditing} /></label>
              <label>Căn hộ / Số nhà<input name="suite" value={editing.address?.suite || ""} onChange={updateEditing} /></label>
              <label className="full">Thành phố<input name="city" value={editing.address?.city || ""} onChange={updateEditing} /></label>
              <div className="form-actions full">
                <button type="button" className="button secondary" onClick={() => setEditing(null)}>Hủy</button>
                <button type="submit" className="button primary">Lưu thay đổi</button>
              </div>
            </form>
          </section>
        </div>
      )}
    </>
  );
}