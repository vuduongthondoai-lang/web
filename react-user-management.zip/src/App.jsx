import { useState } from "react";
import SearchForm from "./components/SearchForm";
import AddUser from "./components/AddUser";
import ResultTable from "./components/ResultTable";

export default function App() {
  // State dùng chung được đặt ở component cha App (State Lifting).
  const [kw, setKeyword] = useState("");
  const [newUser, setNewUser] = useState(null);

  return (
    <main className="page">
      <header className="topbar">
        <div>
          <p className="eyebrow">REACT CRUD APPLICATION</p>
          <h1>Quản lý người dùng</h1>
          <p className="subtitle">Quản lý danh sách, tìm kiếm và cập nhật thông tin người dùng.</p>
        </div>
        <div className="top-icon" aria-hidden="true">👥</div>
      </header>

      <section className="panel">
        <div className="toolbar">
          <SearchForm onChangeValue={setKeyword} />
          <AddUser onAdd={setNewUser} />
        </div>
        <ResultTable
          keyword={kw}
          user={newUser}
          onAdded={() => setNewUser(null)}
        />
      </section>
      <footer>Ứng dụng thực hành ReactJS · CRUD · useState · useEffect</footer>
    </main>
  );
}